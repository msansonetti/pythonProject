from django.shortcuts import render
from django.views.generic import ListView, DetailView
from .models import Director, Pelicula

class DirectorListView(ListView):
    model = Director
    template_name = 'directores.html'
    context_object_name = 'directores'


class PeliculaDetailView(DetailView):
    model = Pelicula
    template_name = 'pelicula.html'
    context_object_name = 'pelicula'

