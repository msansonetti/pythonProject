from django.contrib import admin
from .models import Director, Pelicula

admin.site.register(Director)
admin.site.register(Pelicula)

# Register your models here.
