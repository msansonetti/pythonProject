from django.db import models

# Create your models here.

class Director(models.Model):
    nombre = models.CharField(max_length=30)
    apellido = models.CharField(max_length=30)
    fecha_nacimiento = models.DateField()
    nacionalidad = models.CharField(max_length=35)

    def __str__(self):
        return self.nombre + " " + self.apellido

class Pelicula(models.Model):
    nombre = models.CharField(max_length=50)
    director = models.ForeignKey(Director, on_delete=models.CASCADE)
    categoria = models.CharField(max_length=35)

    def __str__(self):
        return self.nombre